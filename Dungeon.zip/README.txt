CC22: Dungeon

This is my CC22 entry!

Dungeon is a top down dungeon crawler/monster slicer game :3

There is a png of the map included in the folder, just for fun.
Don't go past the spike wall, there is nothing there, unless you go to the top right corner in an emulator, then you will reach random memory land

NOTE: The map will get a complete overhaul now that the contest is over, at which point I will no longer include the map 

HOW TO PLAY:
Transfer the .8xp and the two .8xv files to your calculator and ruun DUNGEON

I recommend putting armor on before you start the game, Which you can do by navigating to the options menu and the the player create menu. The controls for the menu are on the screen.

When in game, the conrols are as follows:
<^v>: move in the direction of the pressed key
[2nd]: attack with the equiped weapon
[y=]-[graph]: each performs the function printed above the key on the screen
[clear]: Quits the game entirely